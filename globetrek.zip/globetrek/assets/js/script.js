function toggleMenu() {
    const nav = document.getElementById("navLinks");
    const auth = document.getElementById("authActions");
    nav.classList.toggle("active");
    if (auth) {
        auth.classList.toggle("active");
    }
}

function confirmAction(message) {
    return confirm(message);
}