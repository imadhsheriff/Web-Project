<?php
include '../includes/db.php';
include '../includes/auth.php';
checkRole('staff');

$message = "";

// review custom travel plans with note and estimated price
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['review_custom_plan'])) {
    $plan_id = intval($_POST['plan_id']);
    $staff_note = mysqli_real_escape_string($conn, $_POST['staff_note']);
    $estimated_price = floatval($_POST['estimated_price']);

    if (empty($staff_note) || $estimated_price <= 0) {
        $message = "<div class='alert alert-error'>Please enter staff note and estimated price.</div>";
    } else {
        $sql = "UPDATE custom_plans 
                SET staff_note='$staff_note', 
                    estimated_price=$estimated_price, 
                    status='Reviewed' 
                WHERE plan_id=$plan_id";

        if (mysqli_query($conn, $sql)) {
            header("Location: dashboard.php?msg=plan_reviewed");
            exit();
        } else {
            $message = "<div class='alert alert-error'>Custom plan review failed.</div>";
        }
    }
}

if (isset($_GET['msg']) && $_GET['msg'] == "plan_reviewed") {
    $message = "<div class='alert alert-success'>Custom travel plan reviewed successfully.</div>";
}

// confirm a customer booking   
if (isset($_GET['confirm_booking'])) {
    $booking_id = intval($_GET['confirm_booking']);

    mysqli_query($conn, "UPDATE bookings SET status='Confirmed' WHERE booking_id=$booking_id");

    header("Location: dashboard.php?msg=confirmed");
    exit();
}

// cancel a customer booking
if (isset($_GET['cancel_booking'])) {
    $booking_id = intval($_GET['cancel_booking']);

    mysqli_query($conn, "UPDATE bookings SET status='Cancelled' WHERE booking_id=$booking_id");

    header("Location: dashboard.php?msg=cancelled");
    exit();
}

if (isset($_GET['msg']) && $_GET['msg'] == "confirmed") {
    $message = "<div class='alert alert-success'>Booking confirmed successfully.</div>";
}

if (isset($_GET['msg']) && $_GET['msg'] == "cancelled") {
    $message = "<div class='alert alert-success'>Booking cancelled successfully.</div>";
}

// mark custom travel plan requests as reviewed
if (isset($_GET['review_plan'])) {
    $plan_id = intval($_GET['review_plan']);

    mysqli_query($conn, "UPDATE custom_plans SET status='Reviewed' WHERE plan_id=$plan_id");

    header("Location: dashboard.php?msg=plan_reviewed");
    exit();
}

if (isset($_GET['msg']) && $_GET['msg'] == "plan_reviewed") {
    $message = "<div class='alert alert-success'>Custom travel plan marked as reviewed.</div>";
}

//reply only to open customer and guest queries
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['reply_query'])) {
    $query_id = intval($_POST['query_id']);
    $reply = mysqli_real_escape_string($conn, $_POST['reply']);

    if (empty($reply)) {
        $message = "<div class='alert alert-error'>Please enter a reply.</div>";
    } else {
        mysqli_query($conn, "UPDATE queries 
                             SET reply='$reply', status='Answered' 
                             WHERE query_id=$query_id AND status='Open'");

        header("Location: dashboard.php?msg=query_replied");
        exit();
    }
}

if (isset($_GET['msg']) && $_GET['msg'] == "query_replied") {
    $message = "<div class='alert alert-success'>Query replied successfully.</div>";
}

// add new packages
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_package'])) {
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $destination = mysqli_real_escape_string($conn, $_POST['destination']);
    $category = mysqli_real_escape_string($conn, $_POST['category']);
    $price = floatval($_POST['price']);
    $duration = mysqli_real_escape_string($conn, $_POST['duration']);
    $image = mysqli_real_escape_string($conn, $_POST['image']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);

    if ($title && $destination && $category && $price && $duration && $image && $description) {
        $sql = "INSERT INTO packages (title, destination, category, price, duration, image, description)
                VALUES ('$title', '$destination', '$category', $price, '$duration', '$image', '$description')";

        if (mysqli_query($conn, $sql)) {
            $message = "<div class='alert alert-success'>New package added successfully.</div>";
        }
    }
}

// update packages
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_package'])) {
    $package_id = intval($_POST['package_id']);
    $price = floatval($_POST['price']);
    $duration = mysqli_real_escape_string($conn, $_POST['duration']);

    if ($package_id && $price && $duration) {
        mysqli_query($conn, "UPDATE packages SET price=$price, duration='$duration' WHERE package_id=$package_id");
        $message = "<div class='alert alert-success'>Package details updated successfully.</div>";
    }
}

// delete a package only if no bookings
if (isset($_GET['delete_package'])) {
    $package_id = intval($_GET['delete_package']);

    // check if package is already used in bookings
    $check_bookings = mysqli_query($conn, "SELECT COUNT(*) AS total FROM bookings WHERE package_id=$package_id");
    $booking_count = mysqli_fetch_assoc($check_bookings)['total'];

    if ($booking_count > 0) {
        header("Location: dashboard.php?msg=package_has_bookings");
        exit();
    } else {
        mysqli_query($conn, "DELETE FROM packages WHERE package_id=$package_id");
        header("Location: dashboard.php?msg=package_deleted");
        exit();
    }
}

if (isset($_GET['msg']) && $_GET['msg'] == "package_deleted") {
    $message = "<div class='alert alert-success'>Package deleted successfully.</div>";
}

if (isset($_GET['msg']) && $_GET['msg'] == "package_has_bookings") {
    $message = "<div class='alert alert-error'>This package cannot be deleted because it already has bookings.</div>";
}

$bookings = mysqli_query($conn, "SELECT bookings.*, 
                                        users.full_name, 
                                        packages.title,
                                        accommodations.name AS accommodation_name,
                                        transport_services.vehicle_name AS transport_name
                                FROM bookings 
                                INNER JOIN users ON bookings.user_id = users.user_id
                                INNER JOIN packages ON bookings.package_id = packages.package_id
                                LEFT JOIN accommodations ON bookings.accommodation_id = accommodations.accommodation_id
                                LEFT JOIN transport_services ON bookings.transport_id = transport_services.transport_id
                                ORDER BY bookings.created_at DESC");

$queries = mysqli_query($conn, "SELECT queries.*, users.full_name, users.email
                               FROM queries 
                               LEFT JOIN users ON queries.user_id = users.user_id
                               ORDER BY queries.created_at DESC");

$packages = mysqli_query($conn, "SELECT * FROM packages ORDER BY package_id DESC");

$custom_plans = mysqli_query($conn, "SELECT custom_plans.*, users.full_name
                                    FROM custom_plans
                                    INNER JOIN users ON custom_plans.user_id = users.user_id
                                    ORDER BY custom_plans.created_at DESC");

include '../includes/header.php';
?>

<section class="dashboard">
    <div class="page-banner" style="width:100%; margin:0;">
        <h1>Staff Dashboard</h1>
        <p>Manage bookings, reply to customer queries, and update travel package details.</p>
    </div>

    <br>
    <?php echo $message; ?>

    <div class="dashboard-grid">
        <div class="dash-card">
            <h3>Booking Management</h3>
            <p>Confirm or cancel customer bookings.</p>
        </div>

        <div class="dash-card">
            <h3>Customer Queries</h3>
            <p>Reply to customer travel questions.</p>
        </div>

        <div class="dash-card">
            <h3>Package Updates</h3>
            <p>Add or update tour package details.</p>
        </div>
    </div>
</section>

<section class="section">
    <div class="section-head">
        <h2>Bookings</h2>
    </div>

    <div class="table-wrap">
        <table>
            <tr>
                <th>Customer</th>
                <th>Package</th>
                <th>Accommodation</th>
                <th>Transport</th>
                <th>Travel Date</th>
                <th>Travellers</th>
                <th>Status</th>
                <th>Action</th>
            </tr>

            <?php while ($row = mysqli_fetch_assoc($bookings)) { ?>
                <tr>
                    <td><?php echo $row['full_name']; ?></td>
                    <td><?php echo $row['title']; ?></td>
                    <td><?php echo htmlspecialchars($row['accommodation_name']); ?></td>
                    <td><?php echo htmlspecialchars($row['transport_name']); ?></td>
                    <td><?php echo $row['travel_date']; ?></td>
                    <td><?php echo $row['travellers']; ?></td>
                    <td><span class="badge"><?php echo $row['status']; ?></span></td>
                        <td>
                            <?php if ($row['status'] == 'Pending') { ?>
                                <div class="action-buttons">
                                    <a class="btn btn-primary" 
                                       href="dashboard.php?confirm_booking=<?php echo $row['booking_id']; ?>" 
                                       onclick="return confirmAction('Confirm this booking?')">
                                       Confirm
                                    </a>

                                    <a class="btn btn-dark" 
                                       href="dashboard.php?cancel_booking=<?php echo $row['booking_id']; ?>" 
                                       onclick="return confirmAction('Cancel this booking?')">
                                       Cancel
                                    </a>
                                </div>

                            <?php } elseif ($row['status'] == 'Confirmed') { ?>
                                <div class="action-buttons">
                                    <a class="btn btn-dark" 
                                       href="dashboard.php?cancel_booking=<?php echo $row['booking_id']; ?>" 
                                       onclick="return confirmAction('Cancel this booking?')">
                                       Cancel
                                    </a>
                                </div>

                            <?php } else { ?>
                                <span class="badge">No Action</span>
                            <?php } ?>
                        </td>                
                </tr>
            <?php } ?>
        </table>
    </div>
</section>

<section class="section">
    <div class="section-head">
        <div>
            <h2>Customer Queries</h2>
            <p>Reply to customer and guest travel queries. Answered queries will be locked from further reply.</p>
        </div>
    </div>

    <div class="table-wrap">
        <table>
            <tr>
                <th>Customer</th>
                <th>Email</th>
                <th>Subject</th>
                <th>Message</th>
                <th>Reply</th>
                <th>Status</th>
                <th>Action</th>
            </tr>

            <?php while ($row = mysqli_fetch_assoc($queries)) { ?>
                <tr>
                    <td>
                        <?php 
                        if (!empty($row['full_name'])) {
                            echo htmlspecialchars($row['full_name']);
                        } else {
                            echo htmlspecialchars($row['guest_name']);
                        }
                        ?>
                    </td>

                    <td>
                        <?php 
                        if (!empty($row['email'])) {
                            echo htmlspecialchars($row['email']);
                        } else {
                            echo htmlspecialchars($row['guest_email']);
                        }
                        ?>
                    </td>

                    <td><?php echo htmlspecialchars($row['subject']); ?></td>
                    <td><?php echo htmlspecialchars($row['message']); ?></td>

                    <td>
                        <?php 
                        if (!empty($row['reply'])) {
                            echo htmlspecialchars($row['reply']);
                        } else {
                            echo "No reply yet";
                        }
                        ?>
                    </td>

                    <td><span class="badge"><?php echo $row['status']; ?></span></td>

                    <td>
                        <?php if ($row['status'] == 'Open') { ?>
                            <form method="POST" class="mini-form">
                                <input type="hidden" name="query_id" value="<?php echo $row['query_id']; ?>">
                                <input type="text" name="reply" placeholder="Write reply">
                                <button class="btn btn-primary" type="submit" name="reply_query">Reply</button>
                            </form>
                        <?php } else { ?>
                            <span class="badge">No Action</span>
                        <?php } ?>
                    </td>
                </tr>
            <?php } ?>
        </table>
    </div>
</section>

<section class="section">
    <div class="section-head">
        <div>
            <h2>Custom Travel Plans</h2>
            <p>Review customer custom travel requests and provide staff feedback with estimated price.</p>
        </div>
    </div>

    <div class="table-wrap">
        <table>
            <tr>
                <th>Customer</th>
                <th>Request Type</th>
                <th>Selected Service</th>
                <th>Destination</th>
                <th>Budget</th>
                <th>Travel Date</th>
                <th>Requirements</th>
                <th>Staff Note</th>
                <th>Estimated Price</th>
                <th>Status</th>
                <th>Action</th>
            </tr>

            <?php while ($row = mysqli_fetch_assoc($custom_plans)) { ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['full_name']); ?></td>

                    <td>
                        <span class="badge">
                            <?php echo htmlspecialchars($row['request_type'] ?? 'General'); ?>
                        </span>
                    </td>

                    <td>
                        <?php 
                        if (!empty($row['selected_service'])) {
                            echo htmlspecialchars($row['selected_service']);
                        } else {
                            echo "General Request";
                        }
                        ?>
                    </td>

                    <td><?php echo htmlspecialchars($row['destination']); ?></td>
                    <td>LKR <?php echo number_format($row['budget'], 2); ?></td>
                    <td><?php echo $row['travel_date']; ?></td>
                    <td><?php echo htmlspecialchars($row['requirements']); ?></td>

                    <td>
                        <?php 
                        if (!empty($row['staff_note'])) {
                            echo htmlspecialchars($row['staff_note']);
                        } else {
                            echo "Not reviewed yet";
                        }
                        ?>
                    </td>

                    <td>
                        <?php 
                        if (!empty($row['estimated_price'])) {
                            echo "LKR " . number_format($row['estimated_price'], 2);
                        } else {
                            echo "Not added";
                        }
                        ?>
                    </td>

                    <td><span class="badge"><?php echo $row['status']; ?></span></td>

                    <td>
                        <?php if ($row['status'] == 'Pending') { ?>
                            <form method="POST" class="review-form">
                                <input type="hidden" name="plan_id" value="<?php echo $row['plan_id']; ?>">

                                <textarea name="staff_note" placeholder="Staff note / quotation"></textarea>

                                <input type="number" name="estimated_price" placeholder="Estimated price">

                                <button class="btn btn-primary" type="submit" name="review_custom_plan">
                                    Submit Review
                                </button>
                            </form>

                        <?php } elseif ($row['status'] == 'Reviewed') { ?>
                            <span class="badge">Waiting for Customer</span>

                        <?php } elseif ($row['status'] == 'Accepted') { ?>
                            <span class="badge">Accepted by Customer</span>

                        <?php } elseif ($row['status'] == 'Rejected') { ?>
                            <span class="badge">Rejected by Customer</span>

                        <?php } else { ?>
                            <span class="badge">No Action</span>
                        <?php } ?>
                    </td>
                </tr>
            <?php } ?>
        </table>
    </div>
</section>

<section class="section">
    <div class="section-head">
        <h2>Add New Package</h2>
    </div>

    <div class="form-box" style="width:100%; margin:0;">
        <form method="POST">
            <div class="grid-2">
                <input type="text" name="title" placeholder="Package Title">
                <input type="text" name="destination" placeholder="Destination">
                <input type="text" name="category" placeholder="Category">
                <input type="number" name="price" placeholder="Price">
                <input type="text" name="duration" placeholder="Duration">
                <input type="text" name="image" placeholder="Image file name, example: ella.jpg">
            </div>

            <br>

            <textarea name="description" placeholder="Package Description"></textarea>

            <br><br>

            <button class="btn btn-primary" type="submit" name="add_package">Add Package</button>
        </form>
    </div>
</section>

<section class="section">
    <div class="section-head">
        <h2>Update Package Price and Duration</h2>
    </div>

    <div class="table-wrap">
        <table>
            <tr>
                <th>Package</th>
                <th>Destination</th>
                <th>Price</th>
                <th>Duration</th>
                <th>Action</th>
            </tr>

            <?php while ($row = mysqli_fetch_assoc($packages)) { ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['title']); ?></td>
                    <td><?php echo htmlspecialchars($row['destination']); ?></td>

                    <td>
                        <input 
                            form="packageForm<?php echo $row['package_id']; ?>" 
                            type="number" 
                            name="price" 
                            value="<?php echo $row['price']; ?>">
                    </td>

                    <td>
                        <input 
                            form="packageForm<?php echo $row['package_id']; ?>" 
                            type="text" 
                            name="duration" 
                            value="<?php echo htmlspecialchars($row['duration']); ?>">
                    </td>

                    <td>
                        <form method="POST" id="packageForm<?php echo $row['package_id']; ?>" class="package-actions">
                            <input type="hidden" name="package_id" value="<?php echo $row['package_id']; ?>">

                            <button class="btn btn-primary" type="submit" name="update_package">Update</button>

                            <a class="btn btn-danger"
                               href="dashboard.php?delete_package=<?php echo $row['package_id']; ?>"
                               onclick="return confirmAction('Are you sure you want to delete this package?')">
                               Delete
                            </a>
                        </form>
                    </td>
                </tr>
            <?php } ?>
        </table>
    </div>
</section>

<?php include '../includes/footer.php'; ?>