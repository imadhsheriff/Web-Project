<?php
include '../includes/db.php';
include '../includes/auth.php';
checkRole('admin');

$message = "";

// block user accounts
if (isset($_GET['block_user'])) {
    $user_id = intval($_GET['block_user']);

    mysqli_query($conn, "UPDATE users SET account_status='Blocked' 
                         WHERE user_id=$user_id AND role!='admin'");

    header("Location: dashboard.php?msg=user_blocked");
    exit();
}

// activate blocked user accounts
if (isset($_GET['activate_user'])) {
    $user_id = intval($_GET['activate_user']);

    mysqli_query($conn, "UPDATE users SET account_status='Active' 
                         WHERE user_id=$user_id AND role!='admin'");

    header("Location: dashboard.php?msg=user_activated");
    exit();
}

if (isset($_GET['msg']) && $_GET['msg'] == "user_blocked") {
    $message = "<div class='alert alert-success'>User account blocked successfully.</div>";
}

if (isset($_GET['msg']) && $_GET['msg'] == "user_activated") {
    $message = "<div class='alert alert-success'>User account activated successfully.</div>";
}

// create new staff accounts 
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['create_staff'])) {
    $full_name = mysqli_real_escape_string($conn, $_POST['full_name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];

    if (empty($full_name) || empty($email) || empty($password)) {
        $message = "<div class='alert alert-error'>Please fill all staff account fields.</div>";
    } else {
        $check = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");

        if (mysqli_num_rows($check) > 0) {
            $message = "<div class='alert alert-error'>This email already exists.</div>";
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            $sql = "INSERT INTO users (full_name, email, password, role)
                    VALUES ('$full_name', '$email', '$hashed_password', 'staff')";

            if (mysqli_query($conn, $sql)) {
                $message = "<div class='alert alert-success'>Staff account created successfully.</div>";
            } else {
                $message = "<div class='alert alert-error'>Staff account creation failed.</div>";
            }
        }
    }
}

$total_customers = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM users WHERE role='customer'"))['total'];
$total_staff = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM users WHERE role='staff'"))['total'];
$total_bookings = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM bookings"))['total'];
$confirmed_bookings = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM bookings WHERE status='Confirmed'"))['total'];
$pending_bookings = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM bookings WHERE status='Pending'"))['total'];
$paid_bookings = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM payments WHERE payment_status='Paid'"))['total'];

$total_sales = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(amount) AS total FROM payments WHERE payment_status='Paid'"))['total'];

if ($total_sales == NULL) {
    $total_sales = 0;
}

// retrieve all user accounts for admin overview
$users = mysqli_query($conn, "SELECT user_id, full_name, email, role, account_status, created_at 
                             FROM users 
                             ORDER BY created_at DESC");

$bookings = mysqli_query($conn, "SELECT bookings.*, 
                                        users.full_name, 
                                        packages.title, 
                                        accommodations.name AS accommodation_name,
                                        transport_services.vehicle_name AS transport_name,
                                        payments.payment_status
                                FROM bookings
                                INNER JOIN users ON bookings.user_id = users.user_id
                                INNER JOIN packages ON bookings.package_id = packages.package_id
                                LEFT JOIN accommodations ON bookings.accommodation_id = accommodations.accommodation_id
                                LEFT JOIN transport_services ON bookings.transport_id = transport_services.transport_id
                                LEFT JOIN payments ON bookings.booking_id = payments.booking_id
                                ORDER BY bookings.created_at DESC");

// generate sales report based on packages and payments
$sales_report = mysqli_query($conn, "SELECT packages.title, 
                                            packages.destination,
                                            COUNT(bookings.booking_id) AS booking_count, 
                                            SUM(payments.amount) AS revenue
                                    FROM packages
                                    LEFT JOIN bookings ON packages.package_id = bookings.package_id
                                    LEFT JOIN payments ON bookings.booking_id = payments.booking_id
                                    GROUP BY packages.package_id
                                    ORDER BY revenue DESC");

include '../includes/header.php';
?>

<section class="dashboard">
    <div class="page-banner" style="width:100%; margin:0;">
        <h1>Admin Dashboard</h1>
        <p>Oversee users, bookings, staff accounts, and sales reports.</p>
    </div>

    <br>
    <?php echo $message; ?>

    <div class="dashboard-grid admin-stats-grid">
        <div class="dash-card">
            <h3>Customers</h3>
            <p><?php echo $total_customers; ?> registered customers</p>
        </div>

        <div class="dash-card">
            <h3>Staff</h3>
            <p><?php echo $total_staff; ?> staff accounts</p>
        </div>

        <div class="dash-card">
            <h3>Total Bookings</h3>
            <p><?php echo $total_bookings; ?> booking records</p>
        </div>

        <div class="dash-card">
            <h3>Confirmed</h3>
            <p><?php echo $confirmed_bookings; ?> confirmed bookings</p>
        </div>

        <div class="dash-card">
            <h3>Pending</h3>
            <p><?php echo $pending_bookings; ?> pending bookings</p>
        </div>

        <div class="dash-card highlight-card">
            <h3>Total Sales</h3>
            <p>LKR <?php echo number_format($total_sales, 2); ?></p>
        </div>
    </div>
</section>

<section class="section">
    <div class="section-head">
        <h2>Create Staff Account</h2>
    </div>

    <div class="form-box" style="width:100%; margin:0;">
        <form method="POST">
            <div class="grid-2">
                <input type="text" name="full_name" placeholder="Staff Full Name">
                <input type="email" name="email" placeholder="Staff Email">
                <input type="password" name="password" placeholder="Password">
            </div>

            <br>

            <button class="btn btn-primary" type="submit" name="create_staff">Create Staff</button>
        </form>
    </div>
</section>

<section class="section">
    <div class="section-head">
        <div>
            <h2>User Account Management</h2>
            <p>Admin can view customers and staff accounts and control account access.</p>
        </div>
    </div>

    <div class="table-wrap">
        <table>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Status</th>
                <th>Created Date</th>
                <th>Action</th>
            </tr>

            <?php while ($row = mysqli_fetch_assoc($users)) { ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['full_name']); ?></td>
                    <td><?php echo htmlspecialchars($row['email']); ?></td>
                    <td><span class="badge"><?php echo $row['role']; ?></span></td>
                    <td><span class="badge"><?php echo $row['account_status']; ?></span></td>
                    <td><?php echo $row['created_at']; ?></td>
                    <td>
                        <?php if ($row['role'] == 'admin') { ?>
                            <span class="badge">Protected</span>
                        <?php } elseif ($row['account_status'] == 'Active') { ?>
                            <a class="btn btn-danger" 
                               href="dashboard.php?block_user=<?php echo $row['user_id']; ?>" 
                               onclick="return confirmAction('Block this account?')">
                               Block
                            </a>
                        <?php } else { ?>
                            <a class="btn btn-primary" 
                               href="dashboard.php?activate_user=<?php echo $row['user_id']; ?>" 
                               onclick="return confirmAction('Activate this account?')">
                               Activate
                            </a>
                        <?php } ?>
                    </td>
                </tr>
            <?php } ?>
        </table>
    </div>
</section>

<section class="section">
    <div class="section-head">
        <h2>Booking Overview</h2>
    </div>

    <div class="table-wrap">
        <table>
            <tr>
                <th>Customer</th>
                <th>Package</th>
                <th>Accommodation</th>
                <th>Transport</th>
                <th>Travel Date</th>
                <th>Travellers</th>
                <th>Payment</th>
                <th>Status</th>
            </tr>

            <?php while ($row = mysqli_fetch_assoc($bookings)) { ?>
                <tr>
                    <td><?php echo $row['full_name']; ?></td>
                    <td><?php echo $row['title']; ?></td>
                    <td><?php echo htmlspecialchars($row['accommodation_name']); ?></td>
                    <td><?php echo htmlspecialchars($row['transport_name']); ?></td>
                    <td><?php echo $row['travel_date']; ?></td>
                    <td><?php echo $row['travellers']; ?></td>
                    <td><?php echo $row['payment_status'] ? $row['payment_status'] : "Not Paid"; ?></td>
                    <td><span class="badge"><?php echo $row['status']; ?></span></td>
                </tr>
            <?php } ?>
        </table>
    </div>
</section>

<section class="section">
    <div class="section-head">
        <div>
            <h2>Professional Sales Report</h2>
            <p>This report shows package performance, revenue, average income, and revenue contribution.</p>
        </div>
    </div>

    <div class="table-wrap">
        <table>
            <tr>
                <th>Package</th>
                <th>Destination</th>
                <th>Total Bookings</th>
                <th>Total Revenue</th>
                <th>Average Revenue</th>
                <th>Sales Share</th>
            </tr>

            <?php while ($row = mysqli_fetch_assoc($sales_report)) { 
                $revenue = $row['revenue'] ? $row['revenue'] : 0;
                $booking_count = $row['booking_count'] ? $row['booking_count'] : 0;

                if ($booking_count > 0) {
                    $average_revenue = $revenue / $booking_count;
                } else {
                    $average_revenue = 0;
                }

                if ($total_sales > 0) {
                    $sales_share = ($revenue / $total_sales) * 100;
                } else {
                    $sales_share = 0;
                }
            ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['title']); ?></td>
                    <td><?php echo htmlspecialchars($row['destination']); ?></td>
                    <td><?php echo $booking_count; ?></td>
                    <td>LKR <?php echo number_format($revenue, 2); ?></td>
                    <td>LKR <?php echo number_format($average_revenue, 2); ?></td>
                    <td>
                        <div class="progress-box">
                            <div class="progress-bar" style="width: <?php echo round($sales_share); ?>%;"></div>
                        </div>
                        <small><?php echo round($sales_share, 1); ?>%</small>
                    </td>
                </tr>
            <?php } ?>
        </table>
    </div>
</section>

<?php include '../includes/footer.php'; ?>