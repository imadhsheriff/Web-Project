<?php
include 'includes/db.php';
include 'includes/auth.php';
checkLogin();

if ($_SESSION['role'] != 'customer') {
    header("Location: index.php");
    exit();
}

if (!isset($_GET['id'])) {
    header("Location: transportation.php");
    exit();
}

$transport_id = intval($_GET['id']);
$user_id = $_SESSION['user_id'];
$message = "";

$result = mysqli_query($conn, "SELECT * FROM transport_services WHERE transport_id = $transport_id");
$transport = mysqli_fetch_assoc($result);

if (!$transport) {
    header("Location: transportation.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $travel_date = $_POST['travel_date'];
    $travellers = intval($_POST['travellers']);

    if (empty($travel_date) || $travellers <= 0) {
        $message = "<div class='alert alert-error'>Please enter date and number of passengers.</div>";
    } elseif ($travel_date < date("Y-m-d")) {
        $message = "<div class='alert alert-error'>Date cannot be in the past.</div>";
    } else {
        $sql = "INSERT INTO bookings 
                (booking_type, user_id, package_id, accommodation_id, transport_id, travel_date, travellers)
                VALUES 
                ('Transportation', $user_id, NULL, NULL, $transport_id, '$travel_date', $travellers)";

        if (mysqli_query($conn, $sql)) {
            $booking_id = mysqli_insert_id($conn);
            header("Location: payment.php?booking_id=$booking_id");
            exit();
        } else {
            $message = "<div class='alert alert-error'>Booking failed.</div>";
        }
    }
}

include 'includes/header.php';
?>

<section class="details-layout">
    <div>
        <img class="details-image" src="/globetrek/assets/images/transport/<?php echo htmlspecialchars($transport['image']); ?>" alt="Transport Image">
    </div>

    <div class="details-card">
        <h1>Book Transport</h1>

        <p><strong>Vehicle:</strong> <?php echo htmlspecialchars($transport['vehicle_name']); ?></p>
        <p><strong>Service:</strong> <?php echo htmlspecialchars($transport['service_type']); ?></p>
        <p><strong>Seats:</strong> <?php echo $transport['seats']; ?></p>
        <p><strong>Price:</strong> LKR <?php echo number_format($transport['price'], 2); ?></p>

        <br>

        <?php echo $message; ?>

        <form method="POST">
            <div class="form-group">
                <label>Travel Date</label>
                <input type="date" name="travel_date">
            </div>

            <div class="form-group">
                <label>Number of Passengers</label>
                <input type="number" name="travellers" min="1" placeholder="Example: 2">
            </div>

            <button class="btn btn-primary" type="submit">Continue to Payment</button>
        </form>
    </div>
</section>

<?php include 'includes/footer.php'; ?>