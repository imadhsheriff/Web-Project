<?php
include 'includes/db.php';
include 'includes/auth.php';
checkLogin();

if ($_SESSION['role'] != 'customer') {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$message = "";

$request_type = "General";
$selected_service = "";

if (isset($_GET['type'])) {
    $request_type = $_GET['type'];
}

if (isset($_GET['service'])) {
    $selected_service = $_GET['service'];
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $destination = mysqli_real_escape_string($conn, $_POST['destination']);
    $budget = floatval($_POST['budget']);
    $travel_date = $_POST['travel_date'];
    $requirements = mysqli_real_escape_string($conn, $_POST['requirements']);
    $request_type = mysqli_real_escape_string($conn, $_POST['request_type']);
    $selected_service = mysqli_real_escape_string($conn, $_POST['selected_service']);

    if (empty($destination) || empty($budget) || empty($travel_date) || empty($requirements)) {
        $message = "<div class='alert alert-error'>Please fill all fields.</div>";
    } elseif ($travel_date < date("Y-m-d")) {
        $message = "<div class='alert alert-error'>Travel date cannot be in the past.</div>";
    } else {
        $sql = "INSERT INTO custom_plans 
                (user_id, request_type, selected_service, destination, budget, travel_date, requirements)
                VALUES 
                ($user_id, '$request_type', '$selected_service', '$destination', $budget, '$travel_date', '$requirements')";

        if (mysqli_query($conn, $sql)) {
            $message = "<div class='alert alert-success'>Your custom request was submitted successfully.</div>";
        } else {
            $message = "<div class='alert alert-error'>Something went wrong. Please try again.</div>";
        }
    }
}

include 'includes/header.php';
?>

<div class="form-box">
    <h1>Custom Travel Request</h1>
    <p>Submit a general custom trip, accommodation request, or transportation request.</p>

    <?php echo $message; ?>

    <form method="POST">
        <div class="form-group">
            <label>Request Type</label>
            <input type="text" name="request_type" value="<?php echo htmlspecialchars($request_type); ?>" readonly>
        </div>

        <div class="form-group">
            <label>Selected Service</label>
            <input type="text" name="selected_service" value="<?php echo htmlspecialchars($selected_service); ?>" placeholder="Selected accommodation or transport service" readonly>
        </div>

        <div class="form-group">
            <label>Destination</label>
            <input type="text" name="destination" placeholder="Preferred Destination">
        </div>

        <div class="form-group">
            <label>Budget in LKR</label>
            <input type="number" name="budget" placeholder="Budget in LKR">
        </div>

        <div class="form-group">
            <label>Travel Date</label>
            <input type="date" name="travel_date">
        </div>

        <div class="form-group">
            <label>Requirements</label>
            <textarea name="requirements" placeholder="Describe your travel, accommodation, or transport needs"></textarea>
        </div>

        <button class="btn btn-primary" type="submit">Submit Request</button>
    </form>
</div>

<?php include 'includes/footer.php'; ?>