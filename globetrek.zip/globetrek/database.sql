DROP DATABASE IF EXISTS globetrek_db;
CREATE DATABASE globetrek_db;
USE globetrek_db;

-- =========================
-- USERS TABLE
-- =========================

CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('customer','staff','admin') DEFAULT 'customer',
    account_status ENUM('Active','Blocked') DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Default password for admin and staff: 123456

INSERT INTO users (full_name, email, password, role, account_status) VALUES
('Admin User', 'admin@globetrek.com', '$2y$12$g2/wBBZ1d8umrDMJMbDejOYnBVuQ5nHrEmzMizoKI9vP1UsJJMiWO', 'admin', 'Active'),
('Staff User', 'staff@globetrek.com', '$2y$12$g2/wBBZ1d8umrDMJMbDejOYnBVuQ5nHrEmzMizoKI9vP1UsJJMiWO', 'staff', 'Active');

-- =========================
-- PACKAGES TABLE
-- =========================

CREATE TABLE packages (
    package_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    destination VARCHAR(100) NOT NULL,
    category VARCHAR(80) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    duration VARCHAR(50) NOT NULL,
    image VARCHAR(255) NOT NULL,
    description TEXT NOT NULL
);

INSERT INTO packages (title, destination, category, price, duration, image, description) VALUES
('Nuwara Eliya Tea Escape', 'Nuwaraeliya', 'Nature Adventure', 36000.00, '2 Days / 1 Night', 'nuwaraeliya.jpg', 'Cool climate, tea plantations, waterfalls, Gregory Lake, and scenic train views.'),
('Knuckles Mountain Trek', 'Knuckles Range', 'Hiking', 39000.00, '2 Days / 1 Night', 'knuckles.jpg', 'Hiking trails, waterfalls, camping, and breathtaking mountain views.'),
('East Coast Paradis', 'Arugambay/Trincomalee', 'Beach Holiday', 52000.00, '3 Days / 2 Nights', 'trincomalee.jpg', 'Surfing, crystal-clear beaches, dolphin watching, and laid-back coastal vibes.'),
('Wild Island Safari', 'Yala', 'Wildlife Tour', 60000.00, '3 Days / 2 Nights', 'yala.jpg', 'A wildlife travel experience with safari rides, nature photography, eco-friendly accommodation, and adventure activities.');


-- =========================
-- ACCOMMODATIONS TABLE
-- =========================

CREATE TABLE accommodations (
    accommodation_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    location VARCHAR(100) NOT NULL,
    type VARCHAR(80) NOT NULL,
    price_range VARCHAR(80) NOT NULL,
    price DECIMAL(10,2) NOT NULL DEFAULT 0,
    image VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    facilities TEXT NOT NULL
);

INSERT INTO accommodations (name, location, type, price_range, price, image, description, facilities) VALUES
('Cloud Mist Villa - NuwaraEliya', 'NuwaraEliya', 'Hill Country Villa', 'LKR 18,000 - 35,000 per night', 25000.00, 'hill-villa.jpg', 'A cozy colonial-style villa surrounded by tea estates and cool misty weather, perfect for a relaxing mountain escape.', 'Tea estate view, fireplace, breakfast, Wi-Fi, hot water, garden access'),
('Negombo City Hotel', 'Negombo', 'City Hotel', 'LKR 10,000 - 22,000 per night', 15000.00, 'city-hotel.jpg', 'A convenient city hotel suitable for airport transfers, short stays, and business travellers.', 'Airport pickup, Wi-Fi, restaurant, air conditioning');


-- =========================
-- TRANSPORT SERVICES TABLE
-- =========================

CREATE TABLE transport_services (
    transport_id INT AUTO_INCREMENT PRIMARY KEY,
    vehicle_name VARCHAR(120) NOT NULL,
    service_type VARCHAR(100) NOT NULL,
    seats INT NOT NULL,
    price_range VARCHAR(80) NOT NULL,
    price DECIMAL(10,2) NOT NULL DEFAULT 0,
    image VARCHAR(255) NOT NULL,
    description TEXT NOT NULL
);

INSERT INTO transport_services (vehicle_name, service_type, seats, price_range, price, image, description) VALUES
('Family Tour Van', 'Group Tour Van', 10, 'LKR 18,000 - 30,000 per day', 22000.00, 'tour-van.jpg', 'Suitable for family trips, group tours, and multi-destination travel plans.'),
('Safari Adventure Jeep', 'Safari Jeep', 6, 'LKR 14,000 - 25,000 per safari', 18000.00, 'safari-jeep.jpg', 'Special transport option for wildlife tours and national park safari experiences.');


-- =========================
-- BOOKINGS TABLE
-- =========================

CREATE TABLE bookings (
    booking_id INT AUTO_INCREMENT PRIMARY KEY,
    booking_type ENUM('Package','Accommodation','Transportation') DEFAULT 'Package',
    user_id INT NOT NULL,
    package_id INT NULL,
    accommodation_id INT NULL,
    transport_id INT NULL,
    travel_date DATE NOT NULL,
    travellers INT NOT NULL,
    status ENUM('Pending','Confirmed','Cancelled') DEFAULT 'Pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (package_id) REFERENCES packages(package_id) ON DELETE SET NULL,
    FOREIGN KEY (accommodation_id) REFERENCES accommodations(accommodation_id) ON DELETE SET NULL,
    FOREIGN KEY (transport_id) REFERENCES transport_services(transport_id) ON DELETE SET NULL
);


-- =========================
-- PAYMENTS TABLE
-- =========================

CREATE TABLE payments (
    payment_id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_method VARCHAR(50) NOT NULL,
    payment_status ENUM('Paid','Failed') DEFAULT 'Paid',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id)
);


-- =========================
-- CUSTOM TRAVEL PLANS TABLE
-- =========================

CREATE TABLE custom_plans (
    plan_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    request_type ENUM('General','Accommodation','Transportation') DEFAULT 'General',
    selected_service VARCHAR(150) DEFAULT NULL,
    destination VARCHAR(100) NOT NULL,
    budget DECIMAL(10,2) NOT NULL,
    travel_date DATE NOT NULL,
    requirements TEXT NOT NULL,
    staff_note TEXT NULL,
    estimated_price DECIMAL(10,2) DEFAULT NULL,
    status ENUM('Pending','Reviewed','Accepted','Rejected') DEFAULT 'Pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (user_id) REFERENCES users(user_id)
);


-- =========================
-- CUSTOMER QUERIES TABLE
-- =========================

CREATE TABLE queries (
    query_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    guest_name VARCHAR(100) NULL,
    guest_email VARCHAR(100) NULL,
    subject VARCHAR(150) NOT NULL,
    message TEXT NOT NULL,
    reply TEXT,
    status ENUM('Open','Answered') DEFAULT 'Open',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (user_id) REFERENCES users(user_id)
);