<?php
include 'includes/db.php';
include 'includes/header.php';

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = mysqli_real_escape_string($conn, $_POST['full_name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];

    if (empty($full_name) || empty($email) || empty($password)) {
        $message = "<div class='alert alert-error'>Please fill all fields.</div>";
    } else {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        $check = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");

        if (mysqli_num_rows($check) > 0) {
            $message = "<div class='alert alert-error'>Email already exists.</div>";
        } else {
            $sql = "INSERT INTO users (full_name, email, password, role)
                    VALUES ('$full_name', '$email', '$hashed_password', 'customer')";

            if (mysqli_query($conn, $sql)) {
                $message = "<div class='alert alert-success'>Registration successful. You can login now.</div>";
            } else {
                $message = "<div class='alert alert-error'>Registration failed.</div>";
            }
        }
    }
}
?>

<div class="form-box">
    <h1>Create Account</h1>
    <p>Register as a customer to book packages and manage travel plans.</p>

    <?php echo $message; ?>

    <form method="POST">
        <div class="form-group">
            <input type="text" name="full_name" placeholder="Full Name">
        </div>

        <div class="form-group">
            <input type="email" name="email" placeholder="Email Address">
        </div>

        <div class="form-group">
            <input type="password" name="password" placeholder="Password">
        </div>

        <button class="btn btn-primary" type="submit">Register</button>

        <p class="form-link">
            Already have an account?
            <a href="login.php">Login here</a>
        </p>
    </form>
</div>

<?php include 'includes/footer.php'; ?>