﻿<?php include 'includes/header.php'; ?>

<section class="page-banner">
    <h1>About GlobeTrek</h1>
    <p>Learn about our travel company, services, and purpose.</p>
</section>

<section class="about-section">
    <div class="about-content">
        <span class="tag" style="background: var(--secondary); color: var(--primary);">Travel company based in Negombo</span>

        <h2>We create smooth, meaningful, and well-planned travel experiences.</h2>

        <p>
            GlobeTrek Adventures is a newly established travel and tourism company located in Negombo.
            The company focuses on helping customers plan, book, and manage their travel experiences
            through a modern web-based platform.
        </p>

        <p>
            The system allows customers to browse available tour packages, view destinations,
            make bookings, request custom travel plans, complete payments, and submit travel queries.
            Staff members can manage bookings, update package details, and respond to customer requests,
            while administrators can oversee users, bookings, staff accounts, and reports.
        </p>

        <div class="about-stats">
            <div>
                <h3>3</h3>
                <p>Main user roles</p>
            </div>

            <div>
                <h3>24/7</h3>
                <p>Online access</p>
            </div>

            <div>
                <h3>100%</h3>
                <p>Travel focused</p>
            </div>
        </div>
    </div>

    <div class="about-image"></div>
</section>

<section class="section">
    <div class="section-head">
        <div>
            <h2>What we offer</h2>
            <p>Our services are designed to support customers from travel planning to final booking.</p>
        </div>
    </div>

    <div class="route-section">
        <div>
            <span>🏝️</span>
            <h3>Tour Packages</h3>
            <p>Customers can browse ready-made packages with destination, activity, and price details.</p>
        </div>

        <div>
            <span>🧳</span>
            <h3>Custom Travel Plans</h3>
            <p>Customers can request personalized plans based on their budget and travel needs.</p>
        </div>

        <div>
            <span>🚐</span>
            <h3>Travel Coordination</h3>
            <p>Staff can coordinate accommodation, transport, and booking confirmations.</p>
        </div>

        <div>
            <span>🔐</span>
            <h3>Secure Management</h3>
            <p>Admin users can manage accounts, reports, and user data securely.</p>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>