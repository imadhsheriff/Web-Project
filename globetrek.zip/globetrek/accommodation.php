<?php
include 'includes/db.php';
include 'includes/header.php';

$accommodations = mysqli_query($conn, "SELECT * FROM accommodations ORDER BY accommodation_id DESC");
?>

<section class="page-banner accommodation-banner">
    <h1>Accommodation</h1>
    <p>Browse accommodation options that match different travel styles, destinations, and budgets.</p>
</section>

<section class="section">
    <div class="section-head">
        <div>
            <h2>Available stays</h2>
            <p>
                Customers can review accommodation options before booking a package or requesting a custom travel plan.
            </p>
        </div>
    </div>

    <div class="option-grid">
        <?php while ($row = mysqli_fetch_assoc($accommodations)) { ?>
            <div class="option-card option-card-reverse">
                <img src="/globetrek/assets/images/accommodation/<?php echo htmlspecialchars($row['image']); ?>" alt="Accommodation Image">

                <div class="option-content">
                    <span class="option-label"><?php echo htmlspecialchars($row['type']); ?></span>
                    <h3><?php echo htmlspecialchars($row['name']); ?></h3>

                    <p><strong>Location:</strong> <?php echo htmlspecialchars($row['location']); ?></p>
                    <p><strong>Price Range:</strong> <?php echo htmlspecialchars($row['price_range']); ?></p>

                    <p><?php echo htmlspecialchars($row['description']); ?></p>

                    <div class="facility-box">
                        <strong>Facilities:</strong>
                        <p><?php echo htmlspecialchars($row['facilities']); ?></p>
                    </div>

                    <a href="accommodation-booking.php?id=<?php echo $row['accommodation_id']; ?>" class="btn btn-primary">
                        Book This Stay
                    </a>

                    <a href="custom-plan.php?type=Accommodation&service=<?php echo urlencode($row['name']); ?>" class="btn btn-light">
                        Request Custom Plan
                    </a>
                </div>
            </div>
        <?php } ?>
    </div>
</section>

<?php include 'includes/footer.php'; ?>