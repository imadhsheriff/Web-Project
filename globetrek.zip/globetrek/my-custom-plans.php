<?php
include 'includes/db.php';
include 'includes/auth.php';
checkLogin();

if ($_SESSION['role'] != 'customer') {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$message = "";

// accept the reviewed custom plan
if (isset($_GET['accept_plan'])) {
    $plan_id = intval($_GET['accept_plan']);

    mysqli_query($conn, "UPDATE custom_plans 
                         SET status='Accepted' 
                         WHERE plan_id=$plan_id 
                         AND user_id=$user_id 
                         AND status='Reviewed'");

    header("Location: my-custom-plans.php?msg=accepted");
    exit();
}

// reject the reviewed custom plan
if (isset($_GET['reject_plan'])) {
    $plan_id = intval($_GET['reject_plan']);

    mysqli_query($conn, "UPDATE custom_plans 
                         SET status='Rejected' 
                         WHERE plan_id=$plan_id 
                         AND user_id=$user_id 
                         AND status='Reviewed'");

    header("Location: my-custom-plans.php?msg=rejected");
    exit();
}

if (isset($_GET['msg']) && $_GET['msg'] == "accepted") {
    $message = "<div class='alert alert-success'>Custom plan accepted successfully.</div>";
}

if (isset($_GET['msg']) && $_GET['msg'] == "rejected") {
    $message = "<div class='alert alert-error'>Custom plan rejected.</div>";
}

$sql = "SELECT * FROM custom_plans 
        WHERE user_id = $user_id 
        ORDER BY created_at DESC";

$result = mysqli_query($conn, $sql);

include 'includes/header.php';
?>

<section class="page-banner">
    <h1>My Custom Requests</h1>
    <p>View your custom travel, accommodation, and transportation requests with staff responses.</p>
</section>

<section class="section">
    <div class="table-wrap">
        <table>
            <tr>
                <th>Request Type</th>
                <th>Selected Service</th>
                <th>Destination</th>
                <th>Budget</th>
                <th>Travel Date</th>
                <th>Requirements</th>
                <th>Staff Note</th>
                <th>Estimated Price</th>
                <th>Status</th>
                <th>Action</th>
            </tr>

            <?php echo $message; ?>
            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                <tr>
                    <td><span class="badge"><?php echo htmlspecialchars($row['request_type']); ?></span></td>

                    <td>
                        <?php 
                        echo !empty($row['selected_service']) 
                            ? htmlspecialchars($row['selected_service']) 
                            : "General Request"; 
                        ?>
                    </td>

                    <td><?php echo htmlspecialchars($row['destination']); ?></td>
                    <td>LKR <?php echo number_format($row['budget'], 2); ?></td>
                    <td><?php echo $row['travel_date']; ?></td>
                    <td><?php echo htmlspecialchars($row['requirements']); ?></td>

                    <td>
                        <?php 
                        echo !empty($row['staff_note']) 
                            ? htmlspecialchars($row['staff_note']) 
                            : "No response yet"; 
                        ?>
                    </td>

                    <td>
                        <?php 
                        echo !empty($row['estimated_price']) 
                            ? "LKR " . number_format($row['estimated_price'], 2) 
                            : "Not added"; 
                        ?>
                    </td>

                    <td><span class="badge"><?php echo $row['status']; ?></span></td>

                    <td>
                        <?php if ($row['status'] == 'Reviewed') { ?>
                            <a class="btn btn-primary" 
                               href="my-custom-plans.php?accept_plan=<?php echo $row['plan_id']; ?>" 
                               onclick="return confirmAction('Accept this custom plan?')">
                               Accept
                            </a>

                            <a class="btn btn-danger" 
                               href="my-custom-plans.php?reject_plan=<?php echo $row['plan_id']; ?>" 
                               onclick="return confirmAction('Reject this custom plan?')">
                               Reject
                            </a>

                        <?php } elseif ($row['status'] == 'Pending') { ?>
                            <span class="badge">Waiting for Review</span>

                        <?php } else { ?>
                            <span class="badge">No Action</span>
                        <?php } ?>
                    </td>
                </tr>
            <?php } ?>
        </table>
    </div>
</section>

<?php include 'includes/footer.php'; ?>