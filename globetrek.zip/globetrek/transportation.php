<?php
include 'includes/db.php';
include 'includes/header.php';

$transport = mysqli_query($conn, "SELECT * FROM transport_services ORDER BY transport_id DESC");
?>

<section class="page-banner transport-banner">
    <h1>Transportation</h1>
    <p>Browse transport services arranged for airport transfers, private tours, group trips, and safari journeys.</p>
</section>

<section class="route-section">
    <div>
        <span>01</span>
        <h3>Select Service</h3>
        <p>Customer chooses the suitable transport option.</p>
    </div>

    <div>
        <span>02</span>
        <h3>Send Request</h3>
        <p>Customer includes transport needs in the custom plan.</p>
    </div>

    <div>
        <span>03</span>
        <h3>Staff Review</h3>
        <p>Travel staff checks the transport availability.</p>
    </div>

    <div>
        <span>04</span>
        <h3>Confirm Travel</h3>
        <p>Transport is arranged with the final booking.</p>
    </div>
</section>

<section class="section">
    <div class="section-head">
        <div>
            <h2>Transport services</h2>
            <p>
                Customers can check available transport options before booking a package or requesting a custom travel plan.
            </p>
        </div>
    </div>

    <div class="option-grid">
        <?php while ($row = mysqli_fetch_assoc($transport)) { ?>
            <div class="option-card">
                <img src="/globetrek/assets/images/transport/<?php echo htmlspecialchars($row['image']); ?>" alt="Transport Image">

                <div class="option-content">
                    <span class="option-label"><?php echo htmlspecialchars($row['service_type']); ?></span>
                    <h3><?php echo htmlspecialchars($row['vehicle_name']); ?></h3>

                    <p><strong>Seats:</strong> <?php echo $row['seats']; ?></p>
                    <p><strong>Price Range:</strong> <?php echo htmlspecialchars($row['price_range']); ?></p>

                    <p><?php echo htmlspecialchars($row['description']); ?></p>

                    <a href="transport-booking.php?id=<?php echo $row['transport_id']; ?>" class="btn btn-primary">
                        Book This Transport
                    </a>

                    <a href="custom-plan.php?type=Transportation&service=<?php echo urlencode($row['vehicle_name']); ?>" class="btn btn-light">
                        Request Custom Plan
                    </a>
                </div>
            </div>
        <?php } ?>
    </div>
</section>

<?php include 'includes/footer.php'; ?>