<?php
include 'includes/db.php';
include 'includes/auth.php';
checkLogin();

if ($_SESSION['role'] != 'customer') {
    header("Location: index.php");
    exit();
}

if (!isset($_GET['id'])) {
    header("Location: packages.php");
    exit();
}

$package_id = intval($_GET['id']);
$user_id = $_SESSION['user_id'];
$message = "";

$package_result = mysqli_query($conn, "SELECT * FROM packages WHERE package_id = $package_id");
$package = mysqli_fetch_assoc($package_result);

if (!$package) {
    header("Location: packages.php");
    exit();
}

$accommodations = mysqli_query($conn, "SELECT * FROM accommodations ORDER BY name ASC");
$transport_services = mysqli_query($conn, "SELECT * FROM transport_services ORDER BY vehicle_name ASC");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $travel_date = $_POST['travel_date'];
    $travellers = intval($_POST['travellers']);

    $accommodation_id = !empty($_POST['accommodation_id']) ? intval($_POST['accommodation_id']) : "NULL";
    $transport_id = !empty($_POST['transport_id']) ? intval($_POST['transport_id']) : "NULL";

    if (empty($travel_date) || $travellers <= 0) {
        $message = "<div class='alert alert-error'>Please enter travel date and number of travellers.</div>";
    } elseif ($travel_date < date("Y-m-d")) {
        $message = "<div class='alert alert-error'>Travel date cannot be in the past.</div>";
    } else {
        $sql = "INSERT INTO bookings 
                (booking_type, user_id, package_id, accommodation_id, transport_id, travel_date, travellers)
                VALUES 
                ('Package', $user_id, $package_id, $accommodation_id, $transport_id, '$travel_date', $travellers)";

        if (mysqli_query($conn, $sql)) {
            $booking_id = mysqli_insert_id($conn);
            header("Location: payment.php?booking_id=$booking_id");
            exit();
        } else {
            $message = "<div class='alert alert-error'>Booking failed: " . mysqli_error($conn) . "</div>";
        }
    }
}

include 'includes/header.php';
?>

<section class="details-layout">
    <div>
        <img class="details-image" src="/globetrek/assets/images/packages/<?php echo htmlspecialchars($package['image']); ?>" alt="Package Image">
    </div>

    <div class="details-card">
        <h1>Book Travel Package</h1>

        <p><strong>Package:</strong> <?php echo htmlspecialchars($package['title']); ?></p>
        <p><strong>Destination:</strong> <?php echo htmlspecialchars($package['destination']); ?></p>
        <p><strong>Package Price per Traveller:</strong> LKR <?php echo number_format($package['price'], 2); ?></p>

        <br>

        <?php echo $message; ?>

        <form method="POST">
            <div class="form-group">
                <label>Travel Date</label>
                <input type="date" name="travel_date">
            </div>

            <div class="form-group">
                <label>Number of Travellers</label>
                <input type="number" name="travellers" min="1" placeholder="Example: 2">
            </div>

            <div class="form-group">
                <label>Select Accommodation (Optional)</label>
                <select name="accommodation_id">
                    <option value="">No accommodation needed</option>
                    <?php while ($row = mysqli_fetch_assoc($accommodations)) { ?>
                        <option value="<?php echo $row['accommodation_id']; ?>">
                            <?php echo htmlspecialchars($row['name']); ?> - LKR <?php echo number_format($row['price'], 2); ?>
                        </option>
                    <?php } ?>
                </select>
            </div>

            <div class="form-group">
                <label>Select Transport (Optional)</label>
                <select name="transport_id">
                    <option value="">No transport needed</option>
                    <?php while ($row = mysqli_fetch_assoc($transport_services)) { ?>
                        <option value="<?php echo $row['transport_id']; ?>">
                            <?php echo htmlspecialchars($row['vehicle_name']); ?> - LKR <?php echo number_format($row['price'], 2); ?>
                        </option>
                    <?php } ?>
                </select>
            </div>

            <button class="btn btn-primary" type="submit">Continue to Payment</button>
        </form>
    </div>
</section>

<?php include 'includes/footer.php'; ?>