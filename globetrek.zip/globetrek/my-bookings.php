<?php
include 'includes/db.php';
include 'includes/auth.php';
checkLogin();

if ($_SESSION['role'] != 'customer') {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$message = "";

// Customer can cancel their own booking
if (isset($_GET['cancel_booking'])) {
    $booking_id = intval($_GET['cancel_booking']);

    mysqli_query($conn, "UPDATE bookings 
                         SET status='Cancelled' 
                         WHERE booking_id=$booking_id 
                         AND user_id=$user_id 
                         AND status!='Cancelled'");

    header("Location: my-bookings.php?msg=cancelled");
    exit();
}

if (isset($_GET['msg']) && $_GET['msg'] == "cancelled") {
    $message = "<div class='alert alert-success'>Booking cancelled successfully.</div>";
}

// LEFT JOIN is used because package, accommodation, or transport can be optional
$sql = "SELECT bookings.*, 
               packages.title AS package_title,
               packages.destination AS package_destination,
               accommodations.name AS accommodation_name,
               transport_services.vehicle_name AS transport_name,
               payments.payment_status
        FROM bookings
        LEFT JOIN packages ON bookings.package_id = packages.package_id
        LEFT JOIN accommodations ON bookings.accommodation_id = accommodations.accommodation_id
        LEFT JOIN transport_services ON bookings.transport_id = transport_services.transport_id
        LEFT JOIN payments ON bookings.booking_id = payments.booking_id
        WHERE bookings.user_id = $user_id
        ORDER BY bookings.created_at DESC";

$result = mysqli_query($conn, $sql);

include 'includes/header.php';
?>

<section class="page-banner">
    <h1>My Bookings</h1>
    <p>View your package, accommodation, and transportation booking requests.</p>
</section>

<section class="section">
    <?php echo $message; ?>

    <div class="table-wrap">
        <table>
            <tr>
                <th>Booking Type</th>
                <th>Package</th>
                <th>Accommodation</th>
                <th>Transport</th>
                <th>Travel Date</th>
                <th>Travellers / Guests</th>
                <th>Payment</th>
                <th>Status</th>
                <th>Action</th>
            </tr>

            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                <tr>
                    <td>
                        <span class="badge">
                            <?php echo htmlspecialchars($row['booking_type']); ?>
                        </span>
                    </td>

                    <td>
                        <?php 
                        echo !empty($row['package_title']) 
                            ? htmlspecialchars($row['package_title']) 
                            : "Not selected"; 
                        ?>
                    </td>

                    <td>
                        <?php 
                        echo !empty($row['accommodation_name']) 
                            ? htmlspecialchars($row['accommodation_name']) 
                            : "Not selected"; 
                        ?>
                    </td>

                    <td>
                        <?php 
                        echo !empty($row['transport_name']) 
                            ? htmlspecialchars($row['transport_name']) 
                            : "Not selected"; 
                        ?>
                    </td>

                    <td><?php echo $row['travel_date']; ?></td>

                    <td><?php echo $row['travellers']; ?></td>

                    <td>
                        <?php 
                        if ($row['payment_status']) {
                            echo "<span class='badge'>Paid</span>";
                        } else {
                            echo "<a class='btn btn-dark' href='payment.php?booking_id=" . $row['booking_id'] . "'>Pay</a>";
                        }
                        ?>
                    </td>

                    <td>
                        <span class="badge">
                            <?php echo $row['status']; ?>
                        </span>
                    </td>

                    <td>
                        <?php if ($row['status'] != 'Cancelled') { ?>
                            <a class="btn btn-danger" 
                               href="my-bookings.php?cancel_booking=<?php echo $row['booking_id']; ?>" 
                               onclick="return confirmAction('Cancel this booking?')">
                               Cancel
                            </a>
                        <?php } else { ?>
                            <span class="badge">No Action</span>
                        <?php } ?>
                    </td>
                </tr>
            <?php } ?>
        </table>
    </div>
</section>

<?php include 'includes/footer.php'; ?>