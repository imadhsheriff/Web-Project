<?php
include 'includes/db.php';
include 'includes/auth.php';
checkLogin();

if ($_SESSION['role'] != 'customer') {
    header("Location: index.php");
    exit();
}

if (!isset($_GET['id'])) {
    header("Location: accommodation.php");
    exit();
}

$accommodation_id = intval($_GET['id']);
$user_id = $_SESSION['user_id'];
$message = "";

$result = mysqli_query($conn, "SELECT * FROM accommodations WHERE accommodation_id = $accommodation_id");
$accommodation = mysqli_fetch_assoc($result);

if (!$accommodation) {
    header("Location: accommodation.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $travel_date = $_POST['travel_date'];
    $travellers = intval($_POST['travellers']);

    if (empty($travel_date) || $travellers <= 0) {
        $message = "<div class='alert alert-error'>Please enter date and number of guests.</div>";
    } elseif ($travel_date < date("Y-m-d")) {
        $message = "<div class='alert alert-error'>Date cannot be in the past.</div>";
    } else {
        $sql = "INSERT INTO bookings 
                (booking_type, user_id, package_id, accommodation_id, transport_id, travel_date, travellers)
                VALUES 
                ('Accommodation', $user_id, NULL, $accommodation_id, NULL, '$travel_date', $travellers)";

        if (mysqli_query($conn, $sql)) {
            $booking_id = mysqli_insert_id($conn);
            header("Location: payment.php?booking_id=$booking_id");
            exit();
        } else {
            $message = "<div class='alert alert-error'>Booking failed.</div>";
        }
    }
}

include 'includes/header.php';
?>

<section class="details-layout">
    <div>
        <img class="details-image" src="/globetrek/assets/images/accommodation/<?php echo htmlspecialchars($accommodation['image']); ?>" alt="Accommodation Image">
    </div>

    <div class="details-card">
        <h1>Book Accommodation</h1>

        <p><strong>Stay:</strong> <?php echo htmlspecialchars($accommodation['name']); ?></p>
        <p><strong>Location:</strong> <?php echo htmlspecialchars($accommodation['location']); ?></p>
        <p><strong>Price:</strong> LKR <?php echo number_format($accommodation['price'], 2); ?></p>

        <br>

        <?php echo $message; ?>

        <form method="POST">
            <div class="form-group">
                <label>Check-in Date</label>
                <input type="date" name="travel_date">
            </div>

            <div class="form-group">
                <label>Number of Guests</label>
                <input type="number" name="travellers" min="1" placeholder="Example: 2">
            </div>

            <button class="btn btn-primary" type="submit">Continue to Payment</button>
        </form>
    </div>
</section>

<?php include 'includes/footer.php'; ?>