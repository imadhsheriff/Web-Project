<?php
include 'includes/db.php';
include 'includes/auth.php';
checkLogin();

if ($_SESSION['role'] != 'customer') {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $subject = mysqli_real_escape_string($conn, $_POST['subject']);
    $query_message = mysqli_real_escape_string($conn, $_POST['message']);

    if (empty($subject) || empty($query_message)) {
        $message = "<div class='alert alert-error'>Please enter subject and message.</div>";
    } else {
        $sql = "INSERT INTO queries (user_id, subject, message)
                VALUES ($user_id, '$subject', '$query_message')";

        if (mysqli_query($conn, $sql)) {
            $message = "<div class='alert alert-success'>Your query was submitted successfully.</div>";
        } else {
            $message = "<div class='alert alert-error'>Query submission failed.</div>";
        }
    }
}

$query_sql = "SELECT * FROM queries WHERE user_id = $user_id ORDER BY created_at DESC";
$query_result = mysqli_query($conn, $query_sql);

include 'includes/header.php';
?>

<section class="page-banner">
    <h1>Travel Queries</h1>
    <p>Submit questions about packages, accommodation, transport, or travel arrangements.</p>
</section>

<div class="form-box">
    <h1>Submit Query</h1>

    <?php echo $message; ?>

    <form method="POST">
        <div class="form-group">
            <input type="text" name="subject" placeholder="Subject">
        </div>

        <div class="form-group">
            <textarea name="message" placeholder="Write your message"></textarea>
        </div>

        <button class="btn btn-primary" type="submit">Send Query</button>
    </form>
</div>

<section class="section">
    <div class="section-head">
        <h2>My Queries</h2>
    </div>

    <div class="table-wrap">
        <table>
            <tr>
                <th>Subject</th>
                <th>Message</th>
                <th>Reply</th>
                <th>Status</th>
            </tr>

            <?php while ($row = mysqli_fetch_assoc($query_result)) { ?>
                <tr>
                    <td><?php echo $row['subject']; ?></td>
                    <td><?php echo $row['message']; ?></td>
                    <td><?php echo $row['reply'] ? $row['reply'] : "No reply yet"; ?></td>
                    <td><span class="badge"><?php echo $row['status']; ?></span></td>
                </tr>
            <?php } ?>
        </table>
    </div>
</section>

<?php include 'includes/footer.php'; ?>