﻿<?php
include 'includes/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $subject = mysqli_real_escape_string($conn, $_POST['subject']);
    $query_message = mysqli_real_escape_string($conn, $_POST['message']);

    if (isset($_SESSION['user_id']) && $_SESSION['role'] == 'customer') {
        // Logged-in customer query
        $user_id = $_SESSION['user_id'];
        $guest_name = "";
        $guest_email = "";
    } else {
        // Guest query
        $user_id = "NULL";
        $guest_name = mysqli_real_escape_string($conn, $_POST['guest_name']);
        $guest_email = mysqli_real_escape_string($conn, $_POST['guest_email']);
    }

    if (empty($subject) || empty($query_message)) {
        $message = "<div class='alert alert-error'>Please enter subject and message.</div>";
    } elseif ($user_id == "NULL" && (empty($guest_name) || empty($guest_email))) {
        $message = "<div class='alert alert-error'>Please enter your name and email address.</div>";
    } else {
        $sql = "INSERT INTO queries (user_id, guest_name, guest_email, subject, message)
                VALUES ($user_id, '$guest_name', '$guest_email', '$subject', '$query_message')";

        if (mysqli_query($conn, $sql)) {
            $message = "<div class='alert alert-success'>Your query was submitted successfully.</div>";
        } else {
            $message = "<div class='alert alert-error'>Something went wrong. Please try again.</div>";
        }
    }
}

include 'includes/header.php';
?>

<section class="page-banner">
    <h1>Contact Us</h1>
    <p>Need help with a package, booking, accommodation, transport, or custom travel plan? Send us your query.</p>
</section>

<section class="contact-layout">
    <div class="contact-form">
        <h2>Send Travel Query</h2>

        <?php if (isset($_SESSION['user_id']) && $_SESSION['role'] == 'customer') { ?>
            <p>You are submitting this query as a logged-in customer.</p>
        <?php } else { ?>
            <p>You can submit a query without creating an account. Please provide your name and email.</p>
        <?php } ?>

        <?php echo $message; ?>

        <form method="POST">
            <?php if (!isset($_SESSION['user_id'])) { ?>
                <div class="form-group">
                    <input type="text" name="guest_name" placeholder="Your Name">
                </div>

                <div class="form-group">
                    <input type="email" name="guest_email" placeholder="Your Email Address">
                </div>
            <?php } ?>

            <div class="form-group">
                <input type="text" name="subject" placeholder="Query Subject">
            </div>

            <div class="form-group">
                <textarea name="message" placeholder="Write your travel query"></textarea>
            </div>

            <button class="btn btn-primary" type="submit">Submit Query</button>
        </form>
    </div>

    <div class="contact-info">
        <span class="tag">Get in touch</span>
        <h2>Talk to GlobeTrek Adventures</h2>

        <p>
            Customers and visitors can use this page to send questions about travel packages,
            accommodation, transportation, payments, and custom travel plans.
        </p>

        <div class="contact-item">
            <strong>Location</strong>
            <p>Negombo, Sri Lanka</p>
        </div>

        <div class="contact-item">
            <strong>Phone</strong>
            <p>+94 77 123 4567</p>
        </div>

        <div class="contact-item">
            <strong>Email</strong>
            <p>info@globetrekadventures.com</p>
        </div>

        <div class="contact-item">
            <strong>Working Hours</strong>
            <p>Monday - Saturday, 9.00 AM - 6.00 PM</p>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>