<?php
include 'includes/db.php';
include 'includes/header.php';

$message = "";

// runs only after the login form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];

    if (empty($email) || empty($password)) {
        $message = "<div class='alert alert-error'>Please enter email and password.</div>";
    } else {
        // search for a user account using the entered email address
        $sql = "SELECT * FROM users WHERE email='$email'"; 
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) == 1) {
            $user = mysqli_fetch_assoc($result);

            // verify the entered password with the hashed password
            if ($user['account_status'] == 'Blocked') {
                $message = "<div class='alert alert-error'>Your account has been blocked. Please contact the administrator.</div>";
            } elseif (password_verify($password, $user['password'])) { 
                $_SESSION['user_id'] = $user['user_id'];
                $_SESSION['full_name'] = $user['full_name'];
                $_SESSION['role'] = $user['role'];

                // redirect users to different dashboards based on their role
                if ($user['role'] == 'admin') {
                    header("Location: admin/dashboard.php");
                } elseif ($user['role'] == 'staff') {
                    header("Location: staff/dashboard.php");
                } else {
                    header("Location: customer/dashboard.php");
                }
                exit();
            } else {
                $message = "<div class='alert alert-error'>Invalid password.</div>";
            }
        } else {
            $message = "<div class='alert alert-error'>No account found with this email.</div>";
        }
    }
}
?>

<div class="form-box">
    <h1>Welcome Back</h1>
    <p>Login to continue your travel planning.</p>

    <?php echo $message; ?>

    <form method="POST">
        <div class="form-group">
            <input type="email" name="email" placeholder="Email Address">
        </div>

        <div class="form-group">
            <input type="password" name="password" placeholder="Password">
        </div>

        <button class="btn btn-primary" type="submit">Login</button>

        <p class="form-link">
            Don't have an account?
            <a href="register.php">Register here</a>
        </p>
    </form>
</div>

<?php include 'includes/footer.php'; ?>