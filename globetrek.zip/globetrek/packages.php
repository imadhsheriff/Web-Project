<?php
include 'includes/db.php';
include 'includes/header.php';

$search = "";

if (isset($_GET['search'])) {
    $search = mysqli_real_escape_string($conn, $_GET['search']);
    $sql = "SELECT * FROM packages 
            WHERE title LIKE '%$search%' 
            OR destination LIKE '%$search%' 
            OR category LIKE '%$search%'";
} else {
    $sql = "SELECT * FROM packages";
}

$result = mysqli_query($conn, $sql);
?>

<section class="page-banner">
    <h1>Tour Packages</h1>
    <p>Search and explore travel packages designed for different types of travellers.</p>
</section>

<section class="section">
    <div class="quick-panel">
        <form action="packages.php" method="GET" class="search-row">
            <input type="text" name="search" placeholder="Search by destination or category" value="<?php echo htmlspecialchars($search); ?>">
            <button class="btn btn-dark" type="submit">Search</button>
        </form>
    </div>
</section>

<section class="section">
    <div class="option-grid option-grid-single">
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
            <div class="option-card">
                <img src="/globetrek/assets/images/packages/<?php echo htmlspecialchars($row['image']); ?>" alt="Package Image">

                <div class="option-content">
                    <span class="option-label"><?php echo htmlspecialchars($row['category']); ?></span>
                    <h3><?php echo $row['title']; ?></h3>

                    <p><strong>Destination:</strong> <?php echo $row['destination']; ?></p>
                    <p><strong>Duration:</strong> <?php echo $row['duration']; ?></p>

                    <p><?php echo substr($row['description'], 0, 140); ?>...</p>
                    <p class="price">LKR <?php echo number_format($row['price'], 2); ?></p>

                    <a class="btn btn-primary" href="package-details.php?id=<?php echo $row['package_id']; ?>">View Details</a>
                </div>
            </div>
        <?php } ?>
    </div>
</section>

<?php include 'includes/footer.php'; ?>