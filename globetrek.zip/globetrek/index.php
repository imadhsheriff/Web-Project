﻿<?php
include 'includes/db.php';
include 'includes/header.php';

$featured = mysqli_query($conn, "SELECT * FROM packages ORDER BY package_id DESC LIMIT 4");
?>

<section class="hero">
    <div class="hero-left">
        <span class="tag">Travel planning from Negombo</span>

        <h1>Explore Sri Lanka with trips made for you.</h1>

        <p>
            GlobeTrek Adventures helps travellers discover tour packages,
            book trips, request custom travel plans, complete payments,
            and contact travel staff through one easy web platform.
        </p>

        <div class="hero-actions">
            <a href="packages.php" class="btn btn-primary">Explore Packages</a>
            <a href="custom-plan.php" class="btn btn-light">Plan Custom Trip</a>
        </div>
    </div>
</section>

<div class="quick-panel">
    <h3>Where do you want to go?</h3>

    <form action="packages.php" method="GET" class="search-row">
        <input type="text" name="search" placeholder="Search Ella, Mirissa, Kandy, Yala...">
        <button class="btn btn-dark" type="submit">Search Packages</button>
    </form>
</div>

<section class="section">
    <div class="section-head">
        <div>
            <h2>Popular destinations</h2>
            <p>
                A few of the most booked tour packages on GlobeTrek right now.
            </p>
        </div>
        <a href="packages.php" class="btn btn-light">View All Packages</a>
    </div>

    <div class="package-grid">
        <?php while ($row = mysqli_fetch_assoc($featured)) { ?>
            <div class="package-card">
                <img class="package-img" src="/globetrek/assets/images/packages/<?php echo htmlspecialchars($row['image']); ?>" alt="Package Image">

                <div class="package-content">
                    <h3><?php echo $row['title']; ?></h3>

                    <div class="package-meta">
                        <span><?php echo $row['destination']; ?></span>
                        <span><?php echo $row['duration']; ?></span>
                    </div>

                    <p class="price">LKR <?php echo number_format($row['price'], 2); ?></p>

                    <a class="btn btn-primary" href="package-details.php?id=<?php echo $row['package_id']; ?>">View Details</a>
                </div>
            </div>
        <?php } ?>
    </div>
</section>

<section class="section">
    <div class="section-head">
        <div>
            <h2>Travel services in one place</h2>
            <p>
                GlobeTrek supports customers, travel agency staff, and administrators
                with the main functions required for a travel and tourism system.
            </p>
        </div>
    </div>

    <div class="feature-list">
        <div class="feature-row">
            <span>🏝️</span>
            <div>
                <h3>Tour Packages</h3>
                <p>Browse packages with destination, activities, duration, and pricing details.</p>
            </div>
        </div>

        <div class="feature-row">
            <span>🧳</span>
            <div>
                <h3>Custom Plans</h3>
                <p>Request a personalized travel plan based on budget, date, and requirements.</p>
            </div>
        </div>

        <div class="feature-row">
            <span>💳</span>
            <div>
                <h3>Booking & Payment</h3>
                <p>Book packages online and complete payment through the travel platform.</p>
            </div>
        </div>

        <div class="feature-row">
            <span>📩</span>
            <div>
                <h3>Travel Queries</h3>
                <p>Submit questions about packages, accommodation, transport, or travel support.</p>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>