<?php
// connects the website with the MySQL database.

$host = "localhost";
$user = "root";
$password = "";
$database = "globetrek_db";

// create connection with MySQL database
$conn = mysqli_connect($host, $user, $password, $database);

// check whether the database connection is successful
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}
?>