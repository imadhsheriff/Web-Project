﻿<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>GlobeTrek Adventures</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="/globetrek/assets/css/style.css">
</head>
<body>

<header class="topbar">
    <a href="/globetrek/index.php" class="brand">
        <div class="brand-icon">✈</div>
        <div>
            <h2>GlobeTrek</h2>
            <small>Adventures</small>
        </div>
    </a>

    <nav class="nav-links" id="navLinks">
        <a href="/globetrek/index.php">Home</a>
        <a href="/globetrek/about.php">About</a>
        <a href="/globetrek/packages.php">Packages</a>
        <a href="/globetrek/accommodation.php">Accommodation</a>
        <a href="/globetrek/transportation.php">Transport</a>
        <a href="/globetrek/contact.php">Contact</a>

        <?php if (isset($_SESSION['role']) && $_SESSION['role'] == 'customer') { ?>
            <a href="/globetrek/customer/dashboard.php">Dashboard</a>
            <a href="/globetrek/my-bookings.php">My Bookings</a>
        <?php } ?>

        <?php if (isset($_SESSION['role']) && $_SESSION['role'] == 'staff') { ?>
            <a href="/globetrek/staff/dashboard.php">Staff Panel</a>
        <?php } ?>

        <?php if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin') { ?>
            <a href="/globetrek/admin/dashboard.php">Admin Panel</a>
        <?php } ?>
    </nav>

    <div class="auth-actions" id="authActions">
        <?php if (isset($_SESSION['user_id'])) { ?>
            <a class="nav-btn" href="/globetrek/logout.php">Logout</a>
        <?php } else { ?>
            <a href="/globetrek/login.php">Login</a>
            <a class="nav-btn" href="/globetrek/register.php">Register</a>
        <?php } ?>
    </div>

    <button class="menu-btn" onclick="toggleMenu()">☰</button>
</header>