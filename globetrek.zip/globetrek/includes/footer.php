<footer class="footer">
    <div class="footer-inner footer-grid">
        <div class="footer-brand">
            <div class="footer-logo">
                <div>
                    <h2>GlobeTrek</h2>
                    <small>Adventures</small>
                </div>
            </div>

            <p>
                GlobeTrek Adventures helps travellers explore Sri Lanka through tour packages,
                custom travel plans, booking support, transport, accommodation, and travel guidance.
            </p>

            <div class="footer-socials">
                <span>Facebook</span>
                <span>Instagram</span>
                <span>WhatsApp</span>
            </div>
        </div>

        <div class="footer-column footer-contact">
            <h3>Contact</h3>
            <p>Negombo, Sri Lanka</p>
            <p>+94 77 123 4567</p>
            <p>info@globetrekadventures.com</p>
            <p>Mon - Sat, 9.00 AM - 6.00 PM</p>
        </div>

        <div class="footer-column">
            <h3>Services</h3>
            <a href="/globetrek/accommodation.php">Accommodation</a>
            <a href="/globetrek/transportation.php">Transportation</a>
            <a href="/globetrek/custom-plan.php">Custom Travel Plan</a>
            <a href="/globetrek/contact.php">Contact Us</a>
        </div>

        <div class="footer-column">
            <h3>Explore</h3>
            <a href="/globetrek/index.php">Home</a>
            <a href="/globetrek/about.php">About</a>
            <a href="/globetrek/packages.php">Packages</a>
        </div>
    </div>

    <div class="footer-bottom">
        <p>&copy; 2026 GlobeTrek Adventures. All Rights Reserved.</p>
    </div>
</footer>

<script src="/globetrek/assets/js/script.js"></script>
</body>
</html>