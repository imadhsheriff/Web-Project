<?php
// authentication helper file
// protect pages from unauthorized access.

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// checks whether the user is logged in
function checkLogin() {
    if (!isset($_SESSION['user_id'])) {
        header("Location: /globetrek/login.php");
        exit();
    }
}

// checks whether the logged in user has the correct role
function checkRole($role) {
    if (!isset($_SESSION['role']) || $_SESSION['role'] !== $role) {
        header("Location: /globetrek/login.php");
        exit();
    }
}
?>