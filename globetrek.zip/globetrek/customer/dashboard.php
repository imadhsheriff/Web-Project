<?php
include '../includes/db.php';
include '../includes/auth.php';
checkRole('customer');

$user_id = $_SESSION['user_id'];

$booking_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM bookings WHERE user_id = $user_id"))['total'];
$plan_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM custom_plans WHERE user_id = $user_id"))['total'];
$query_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM queries WHERE user_id = $user_id"))['total'];

include '../includes/header.php';
?>

<section class="dashboard">
    <div class="page-banner" style="width:100%; margin:0;">
        <h1>Customer Dashboard</h1>
        <p>Welcome, <?php echo $_SESSION['full_name']; ?>. Manage your bookings, custom plans, and travel queries.</p>
    </div>

    <div class="dashboard-grid">
        <div class="dash-card">
            <h3>My Bookings</h3>
            <p><?php echo $booking_count; ?> booking requests</p>
            <br>
            <a class="btn btn-primary" href="../my-bookings.php">View Bookings</a>
        </div>

        <div class="dash-card">
            <h3>Custom Plans</h3>
            <p><?php echo $plan_count; ?> custom plan requests</p>
            <br>
            <a class="btn btn-primary" href="../custom-plan.php">Create Plan</a>
            <a class="btn btn-dark" href="../my-custom-plans.php">View Requests</a>
        </div>

        <div class="dash-card">
            <h3>Travel Queries</h3>
            <p><?php echo $query_count; ?> submitted queries</p>
            <br>
            <a class="btn btn-primary" href="../queries.php">Ask Question</a>
        </div>
    </div>
</section>

<?php include '../includes/footer.php'; ?>