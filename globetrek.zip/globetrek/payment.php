<?php
include 'includes/db.php';
include 'includes/auth.php';
checkLogin();

if ($_SESSION['role'] != 'customer') {
    header("Location: index.php");
    exit();
}

if (!isset($_GET['booking_id'])) {
    header("Location: my-bookings.php");
    exit();
}

$booking_id = intval($_GET['booking_id']);
$user_id = $_SESSION['user_id'];
$message = "";

$sql = "SELECT bookings.*, 
               packages.title AS package_title,
               packages.destination AS package_destination,
               packages.price AS package_price,
               accommodations.name AS accommodation_name,
               accommodations.price AS accommodation_price,
               transport_services.vehicle_name AS transport_name,
               transport_services.price AS transport_price
        FROM bookings
        LEFT JOIN packages ON bookings.package_id = packages.package_id
        LEFT JOIN accommodations ON bookings.accommodation_id = accommodations.accommodation_id
        LEFT JOIN transport_services ON bookings.transport_id = transport_services.transport_id
        WHERE bookings.booking_id = $booking_id AND bookings.user_id = $user_id";

$result = mysqli_query($conn, $sql);
$booking = mysqli_fetch_assoc($result);

if (!$booking) {
    header("Location: my-bookings.php");
    exit();
}

$package_total = !empty($booking['package_price']) ? $booking['package_price'] * $booking['travellers'] : 0;
$accommodation_price = !empty($booking['accommodation_price']) ? $booking['accommodation_price'] : 0;
$transport_price = !empty($booking['transport_price']) ? $booking['transport_price'] : 0;

$amount = $package_total + $accommodation_price + $transport_price;

$payment_check = mysqli_query($conn, "SELECT * FROM payments WHERE booking_id = $booking_id");
$already_paid = mysqli_num_rows($payment_check) > 0;

if ($_SERVER["REQUEST_METHOD"] == "POST" && !$already_paid) {
    $payment_method = mysqli_real_escape_string($conn, $_POST['payment_method']);

    if (empty($payment_method)) {
        $message = "<div class='alert alert-error'>Please select a payment method.</div>";
    } else {
        $payment_sql = "INSERT INTO payments (booking_id, amount, payment_method, payment_status)
                        VALUES ($booking_id, $amount, '$payment_method', 'Paid')";

        if (mysqli_query($conn, $payment_sql)) {
            $message = "<div class='alert alert-success'>Payment completed successfully. Your booking is waiting for staff confirmation.</div>";
            $already_paid = true;
        } else {
            $message = "<div class='alert alert-error'>Payment failed.</div>";
        }
    }
}

include 'includes/header.php';
?>

<div class="form-box">
    <h1>Payment</h1>
    <p>Complete your payment for the selected travel service.</p>

    <?php echo $message; ?>

    <p><strong>Booking Type:</strong> <?php echo htmlspecialchars($booking['booking_type']); ?></p>
    <p><strong>Travellers / Guests:</strong> <?php echo $booking['travellers']; ?></p>

    <br>

    <?php if (!empty($booking['package_title'])) { ?>
        <p><strong>Package:</strong> <?php echo htmlspecialchars($booking['package_title']); ?></p>
        <p><strong>Package Total:</strong> LKR <?php echo number_format($package_total, 2); ?></p>
    <?php } ?>

    <?php if (!empty($booking['accommodation_name'])) { ?>
        <p><strong>Accommodation:</strong> <?php echo htmlspecialchars($booking['accommodation_name']); ?></p>
        <p><strong>Accommodation Price:</strong> LKR <?php echo number_format($accommodation_price, 2); ?></p>
    <?php } ?>

    <?php if (!empty($booking['transport_name'])) { ?>
        <p><strong>Transport:</strong> <?php echo htmlspecialchars($booking['transport_name']); ?></p>
        <p><strong>Transport Price:</strong> LKR <?php echo number_format($transport_price, 2); ?></p>
    <?php } ?>

    <br>

    <p><strong>Total Amount:</strong> LKR <?php echo number_format($amount, 2); ?></p>

    <br>

    <?php if ($already_paid) { ?>
        <div class="alert alert-success">This booking has already been paid.</div>
        <a class="btn btn-dark" href="my-bookings.php">View My Bookings</a>
    <?php } else { ?>
        <form method="POST">
            <div class="form-group">
                <label>Payment Method</label>
                <select name="payment_method">
                    <option value="">Select Method</option>
                    <option value="Card Payment">Card Payment</option>
                    <option value="Bank Transfer">Bank Transfer</option>
                    <option value="Online Wallet">Online Wallet</option>
                </select>
            </div>

            <button class="btn btn-primary" type="submit">Pay Now</button>
        </form>
    <?php } ?>
</div>

<?php include 'includes/footer.php'; ?>