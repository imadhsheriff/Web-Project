<?php
include 'includes/db.php';
include 'includes/header.php';

if (!isset($_GET['id'])) {
    header("Location: packages.php");
    exit();
}

$id = intval($_GET['id']);
$sql = "SELECT * FROM packages WHERE package_id = $id";
$result = mysqli_query($conn, $sql);
$package = mysqli_fetch_assoc($result);

if (!$package) {
    header("Location: packages.php");
    exit();
}
?>

<section class="details-layout">
    <div>
        <img class="details-image" src="/globetrek/assets/images/packages/<?php echo htmlspecialchars($package['image']); ?>" alt="Package Image">
    </div>

    <div class="details-card">
        <span class="tag" style="color:#08111f; border-color:#e5e7eb;"><?php echo $package['category']; ?></span>
        <h1><?php echo $package['title']; ?></h1>

        <p><strong>Destination:</strong> <?php echo $package['destination']; ?></p>
        <p><strong>Duration:</strong> <?php echo $package['duration']; ?></p>
        <p><strong>Price:</strong> LKR <?php echo number_format($package['price'], 2); ?></p>

        <br>

        <p><?php echo $package['description']; ?></p>

        <br>

        <a class="btn btn-primary" href="booking.php?id=<?php echo $package['package_id']; ?>">Book This Package</a>
    </div>
</section>

<?php include 'includes/footer.php'; ?>